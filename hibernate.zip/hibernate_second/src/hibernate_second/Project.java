package hibernate_second;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Project {
	
	@Id
	private int pid;
	private String pname;
	private String plocation;
	
	
	public Project() {
		super();
	}


	public Project(int pid, String pname, String plocation) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.plocation = plocation;
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public String getPlocation() {
		return plocation;
	}


	public void setPlocation(String plocation) {
		this.plocation = plocation;
	}


	@Override
	public String toString() {
		return "Project [pid=" + pid + ", pname=" + pname + ", plocation=" + plocation + "]";
	}
	
	
	

}
