package hibernate_second;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Projcet_Client {
	
	public static void main(String[] args) {
		
		 Configuration cgf=new Configuration();
		 cgf.configure();
		 cgf.addAnnotatedClass(Project.class);
		 SessionFactory factory =cgf.buildSessionFactory();
		 Session session =factory.openSession();
		 
		  Project project=session.load(Project.class, 3);
		  System.out.println(project);
	}

}
